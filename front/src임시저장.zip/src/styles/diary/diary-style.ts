import styled from "styled-components";
import { color } from "@/styles/common/colorPalette";

export const DiarySection = styled.section`
    padding: 70px 0;
`;
