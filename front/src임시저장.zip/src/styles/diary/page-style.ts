import styled from "styled-components";
import { color } from "@/styles/common/colorPalette";

export const Wrapper = styled.section`
    background: ${color.beige};
`;
