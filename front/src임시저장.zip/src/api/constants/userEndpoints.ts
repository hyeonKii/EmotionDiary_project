export const USER_EDIT_NICKNAME = "users/nickname";
export const USER_DELETE = "users/withdrawal";
