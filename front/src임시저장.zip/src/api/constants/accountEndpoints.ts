export const ACCOUNT_REGISTER = "account/new";
export const ACCOUNT_LOGIN = "account/login";
export const ACCOUNT_GET = "account";
export const ACCOUNT_LOGOUT = "account";
export const ACCOUNT_FIND_ID = "account/user-id";
export const ACCOUNT_CHANGE_PASSWORD = "account/password";
export const ACCOUNT_CHECK_ID = "account/certify";
