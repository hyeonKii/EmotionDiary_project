export const MESSEGE_GET = "chats/all";
export const MESSEGE_COUNT = "chats/count";
export const MESSEGE_READ_UPDATE = "chats/read";
