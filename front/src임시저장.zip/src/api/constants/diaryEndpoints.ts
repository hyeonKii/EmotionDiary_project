export const DIARY_WRITE = "diaries/write";
export const DIARY_GET = "diaries/all";
export const MYDIARY = "diaries";
export const DIARY_GET_MY_ALL = "diaries/mine";
export const DIARY_MONTH = "diaries/";
