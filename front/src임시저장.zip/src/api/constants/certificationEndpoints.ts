export const CERTIFICATION_EMAIL_SEND_CODE = "certification/send";
export const CERTIFICATION_EMAIL_CHECK_CODE = "certification/certify";
