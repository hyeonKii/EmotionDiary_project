// const PORT = process.env.PORT;
const PORT = 3002;
export const URL = "http://" + window.location.hostname + ":" + PORT + "/api/";
