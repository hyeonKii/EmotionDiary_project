export default function Loading() {
    return <div>로딩 중...</div>;
}
