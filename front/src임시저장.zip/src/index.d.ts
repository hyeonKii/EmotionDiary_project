declare module "*.jpg";
declare module "*.ttf";
declare module "*.png";
